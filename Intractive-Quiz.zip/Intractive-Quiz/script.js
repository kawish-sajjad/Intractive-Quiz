
$(document).ready(function(){

  var right_answers = ["Republic", "Himalayas" ,"President" , "China" , "1998"];
  var your_answers = [];
  $("button").click(function(){
        //  question that is showing 
        var active_q =  $(".question.block");

        // answer of selected question
        var active_answer = $(active_q).find("input:checked").val();
        console.log(right_answers);

        // make answers array and push users enterd values
        your_answers.push(active_answer);

        // get the displing quesion no.
        var q_no = $(".question").filter(".block").index();

        // console.log(right_answers[q_no-1], active_answer);
        // console.log(q_no-1);

        if (right_answers[q_no-1] == active_answer ) {
            // alert("Correct Answer");
        }else {

            // alert("Not Correct Answer");
        }

        if ( !$(".question.block").hasClass("last-question") ) {

            $(active_q).next(".question").addClass("block");
            $(active_q).next(".question").removeClass("hidden");

            $(active_q).removeClass("block");
            $(active_q).addClass("hidden");
        }else {

            $(active_q).removeClass("block");
            $(active_q).addClass("hidden");

            $(".container-ans").slideDown(1000);
            $(".Submit-button").hide();

            $.each(right_answers, function(index, item) {

                var html = '<div> Qno'+(index+1)+' Ans:'+item+'</div>';
                $(".correct-answers").append(html);

                var html2 = '<div> Qno'+(index+1)+' Ans:'+your_answers[index]+'</div>';
                $(".yours-answers").append(html2);
            });
            
        }

        
    });

    $(".Start-Quiz").click( function(){
            $(".main-box").slideDown(500);
    });

    $(".Start-Quiz").click( function(){
            $(".Start-Quiz").hide();
    });

});
